# cleans previous results from the memory
rm(list=ls())
graphics.off()
readline(prompt="Press [enter] to continue")

imageDirectory <- "D:\\Task Stage\\Task - MovieLens\\datasets\\ml-1m\\prototype20\\T04\\tools_analyses"
setwd(imageDirectory)

#-------------------------------------------------------------------------------------------------------------------
# Installs packages
#-------------------------------------------------------------------------------------------------------------------

#install.packages("compute.es")
#install.packages("ez")
#install.packages("ggplot2")
#install.packages("multcomp")
#install.packages("nlme")
#install.packages("pastecs")
#install.packages("reshape")
#install.packages("akima")
#install.packages("WRS", repos="http://R-Forge.R-project.org")
#install.packages("Hmisc")

# loads packages
library(compute.es)
library(ez)
library(ggplot2)
library(multcomp)
library(nlme)
library(pastecs)
library(reshape)
library(WRS)
library(Hmisc)
#source("http://www-rcf.usc.edu/~rwilcox/Rallfun-v14")

library(reticulate)
library(psych)
library(dplyr)
library(car)

#-------------------------------------------------------------------------------------------------------------------
# Loads experimental data
#-------------------------------------------------------------------------------------------------------------------

# loads the data from a python pickled dataframe
PARAM_PYTHONPATH = "C:\\Users\\Andre\\Miniconda3\\envs\\movielens\\python.exe"
PARAM_SOURCEPATH = "D:\\Task Stage\\Task - MovieLens\\datasets\\ml-1m\\prototype20\\T04\\tools_analyses"
PARAM_DATAGROUP  = "g8"
PARAM_DATAFRAME  = paste("dataframe_m1_", PARAM_DATAGROUP, ".pkl", sep="")

surprise = py_load_object(file.path(PARAM_SOURCEPATH, PARAM_DATAFRAME), pickle = "pickle")

# loads the data from delimited text file created from a python pickled dataframe
#PARAM_SOURCEPATH = ...
#PARAM_DATAFRAME  = ...
#surprise <- read.delim(file.path(PARAM_SOURCEPATH, PARAM_DATAFRAME), header = TRUE)#, row.names = NULL)
#surprise$X <- NULL # removes column with row names

surprise$participant <- factor(surprise$participant)
surprise$config      <- factor(surprise$config)
surprise$itemrep     <- factor(surprise$itemrep)
surprise$itemcmp     <- factor(surprise$itemcmp)
#surprise$metric      <- surprise$norm

surprise$interval    <- NULL
surprise$algorithm   <- NULL
surprise$weighting   <- NULL
surprise$smoothing   <- NULL
#surprise$score       <- NULL
#surprise$norm        <- NULL

surprise<-surprise[order(surprise$participant),]
str(surprise)

#-------------------------------------------------------------------------------------------------------------------
# Explores data using standard graphs and summary reports
#
# to save the graphs, use:
#
#    imageFile <- paste(imageDirectory,"filename.png",sep="/")
#    ggsave(file = imageFile)
#-------------------------------------------------------------------------------------------------------------------

# Figure 1
plot.new()

n_rows = 2
n_cols = 5
n_figs = n_rows * n_cols
layout(matrix(c(1:n_figs), n_rows, n_cols, byrow=T))
layout.show(n=n_figs)

hist(surprise$score,                                   xlab = "Surprise", col = "blue", main = "General")
hist(surprise[surprise$itemrep == "Model C",]$score,   xlab = "Surprise", col = "gray", main = "Config C*")
hist(surprise[surprise$itemrep == "Model U",]$score,   xlab = "Surprise", col = "gray", main = "Config U*")
hist(surprise[surprise$itemrep == "Model D",]$score,   xlab = "Surprise", col = "gray", main = "Config D*")
hist(surprise[surprise$itemrep == "Model V",]$score,   xlab = "Surprise", col = "gray", main = "Config V*")

subtitle="Normal Q-Q plot for Surprise"
# -- you may want to apply the shapiro test on a resample: shapiro.test(surprise[seq(1,60,5),]$score)$p.value, digits=3)
qqPlot(surprise$score,                                 ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("General ( p-value = ",   format(shapiro.test(surprise$score)$p.value,                                 digits=3), ")"))
qqPlot(surprise[surprise$itemrep == "Model C",]$score, ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("Config C* ( p-value = ", format(shapiro.test(surprise[surprise$itemrep == "Model C",]$score)$p.value, digits=3), ")"))
qqPlot(surprise[surprise$itemrep == "Model U",]$score, ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("Config U* ( p-value = ", format(shapiro.test(surprise[surprise$itemrep == "Model U",]$score)$p.value, digits=3), ")"))
qqPlot(surprise[surprise$itemrep == "Model D",]$score, ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("Config D* ( p-value = ", format(shapiro.test(surprise[surprise$itemrep == "Model D",]$score)$p.value, digits=3), ")"))
qqPlot(surprise[surprise$itemrep == "Model V",]$score, ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("Config V* ( p-value = ", format(shapiro.test(surprise[surprise$itemrep == "Model V",]$score)$p.value, digits=3), ")"))

readline(prompt="Press [enter] to continue")

plot.new()

n_rows = 2
n_cols = 3
n_figs = n_rows * n_cols
layout(matrix(c(1:n_figs), n_rows, n_cols, byrow=T))
layout.show(n=n_figs)

hist(surprise$score,                                               xlab = "Surprise", col="blue",                       main = "General")
hist(surprise[surprise$itemcmp == "Euclidean",]$score,             xlab = "Surprise", col="gray",                       main = "Config *0")
hist(surprise[surprise$itemcmp == "cosine",]$score,                xlab = "Surprise", col="gray",                       main = "Config *1")





qqPlot(surprise$score,                                             ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("General ( p-value = ",   format(shapiro.test(surprise$score)$p.value,                                          digits=3), ")"))
qqPlot(surprise[surprise$itemcmp == "Euclidean",]$score,           ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("Config *0 ( p-value = ", format(shapiro.test(surprise[surprise$itemcmp == "Euclidean",]$score)$p.value,        digits=3), ")"))
qqPlot(surprise[surprise$itemcmp == "cosine",]$score,              ylab = "Surprise", col = "blue", col.lines = "gray", main = paste("Config *1 ( p-value = ", format(shapiro.test(surprise[surprise$itemcmp == "cosine",]$score)$p.value,           digits=3), ")"))





readline(prompt="Press [enter] to continue")

plot.new()

surpriseBoxplot <- ggplot(surprise, aes(itemcmp, metric))
surpriseBoxplot + geom_boxplot() + facet_wrap(~itemrep, nrow = 1) + labs(x = "Item Comparison", y = "Mean Surprise Metric")
readline(prompt="Press [enter] to continue")

itemrepBar <- ggplot(surprise, aes(itemrep, metric))
itemrepBar + stat_summary(fun.y = mean, geom = "bar", fill = "White", colour = "Black") + stat_summary(fun.data = mean_cl_boot, geom = "pointrange") + labs(x = "Item Representation", y = "Mean Surprise") 
readline(prompt="Press [enter] to continue")

surpriseBoxplot <- ggplot(surprise, aes(itemrep, metric))
surpriseBoxplot + geom_boxplot() + facet_wrap(~itemcmp, nrow = 1) + labs(x = "Item Representation", y = "Mean Surprise Metric")
readline(prompt="Press [enter] to continue")

itemcmpBar <- ggplot(surprise, aes(itemcmp, metric))
itemcmpBar + stat_summary(fun.y = mean, geom = "bar", fill = "White", colour = "Black") + stat_summary(fun.data = mean_cl_boot, geom = "pointrange") + labs(x = "Item Comparison", y = "Mean Surprise") 
readline(prompt="Press [enter] to continue")

surpriseInt <- ggplot(surprise, aes(itemrep, metric, colour = itemcmp))
surpriseInt + stat_summary(fun.y = mean, geom = "point") + stat_summary(fun.y = mean, geom = "line", aes(group= itemcmp)) + stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.2) + labs(x = "Item Representation", y = "Mean Surprise", colour = "Item Comparison") 
readline(prompt="Press [enter] to continue")

surpriseInt <- ggplot(surprise, aes(itemcmp, metric, colour = itemrep))
surpriseInt + stat_summary(fun.y = mean, geom = "point") + stat_summary(fun.y = mean, geom = "line", aes(group= itemrep)) + stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.2) + labs(x = "Item Comparison", y = "Mean Surprise", colour = "Item Representation") 
readline(prompt="Press [enter] to continue")

#options(digits = 3)
#by(surprise$metric, list(surprise$itemrep, surprise$itemcmp), stat.desc, basic = FALSE)
#by(surprise$metric, surprise$itemrep, stat.desc, basic = FALSE)
#by(surprise$metric, surprise$itemcmp, stat.desc, basic = FALSE)
#options(digits = 7)
#readline(prompt="Press [enter] to continue")


#-------------------------------------------------------------------------------------------------------------------
# Setting contrasts
#-------------------------------------------------------------------------------------------------------------------

# contrasts for 4x2 factorial experiment

# -- for itemrep, with four levels
FullVsFactorised    <- c(1, -1, 1, -1) # it was like this: c(1, -1, -1, 1)
FullContentVsRating <- c(1, 0, -1, 0)  #                   c(1, 0, 0, -1)
FactContentVsRating <- c(0, 1, 0, -1)  #                   c(0, -1, 1, 0)
contrasts(surprise$itemrep)<-cbind(FullVsFactorised, FullContentVsRating, FactContentVsRating)

# for itemcmp, with six levels
NegSkewVsOther<-c(1, -1)     # negalively skewd distance distribution vs else
contrasts(surprise$itemcmp) <- NegSkewVsOther




# Inspect if contrasts were properly set (weights fall in the proper variables)

surprise$itemrep
readline(prompt="Inspect if contrasts were properly set. Press [enter] to continue")
surprise$itemcmp
readline(prompt="Inspect if contrasts were properly set. Press [enter] to continue")

#-------------------------------------------------------------------------------------------------------------------
# Performing ANOVA using multilevel linear model (lme)
#-------------------------------------------------------------------------------------------------------------------

baseline<-lme(metric ~ 1, random = ~1|participant/itemrep/itemcmp, data = surprise, method = "ML")
itemrepModel<-update(baseline, .~. + itemrep)
itemcmpModel<-update(itemrepModel, .~. + itemcmp)
surpriseModel<-update(itemcmpModel, .~. + itemrep:itemcmp)

anova(baseline, itemrepModel, itemcmpModel, surpriseModel)
readline(prompt="Press [enter] to continue")

summary(surpriseModel) 
readline(prompt="Press [enter] to continue")

#surpriseModel<-lme(metric ~ itemrep*itemcmp, random = ~1|participant/itemrep/itemcmp, data = surprise)
#summary(surpriseModel) 

#postHocs<-glht(surpriseModel, linfct = mcp(itemrep = "Tukey"))
#summary(postHocs)
#confint(postHocs)

#postHocs<-glht(surpriseModel, linfct = mcp(itemcmp = "Tukey"))
#summary(postHocs)
#confint(postHocs)

#-------------------------------------------------------------------------------------------------------------------
# Performing ANOVA using ezAnova
#-------------------------------------------------------------------------------------------------------------------

surpriseModel<-ezANOVA(data = surprise, dv = .(metric), wid = .(participant),  within = .(itemrep, itemcmp), type = 3, detailed = TRUE)
options(digits = 3)
surpriseModel

pairwise.t.test(surprise$metric, surprise$config, paired = TRUE, p.adjust.method = "bonferroni")
options(digits = 7)

#-------------------------------------------------------------------------------------------------------------------
# Computing effect sizes
#-------------------------------------------------------------------------------------------------------------------

rcontrast<-function(t, df)
{r<-sqrt(t^2/(t^2 + df))
print(paste("r = ", r))
}

# remember to manually update these values from t-value and df for each contrast reported by summary(surpriseModel) 

# Contrast: Full vs Factorised
rcontrast(-7.65, 76)
surprise$ct_itemrep <- ifelse(surprise$itemrep %in% c("Model C", "Model U"), "Full", "Factorised")
surpriseInt <- ggplot(surprise, aes(itemcmp, metric, colour = ct_itemrep))
#surpriseInt + stat_summary(fun.y = mean, geom = "point") + stat_summary(fun.y = mean, geom = "line", aes(group= ct_itemrep)) + stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.2) + labs(x = "Item Comparison", y = "Mean Surprise", colour = "Item Representation") + ggtitle("Contrast: Full vs Factorised")
surpriseInt + 
  stat_summary(fun.y = mean, geom = "point", size = 5, show.legend=FALSE) + 
  stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.05, size = 2, show.legend=FALSE) + 
  stat_summary(fun.y = mean, geom = "line", aes(group=ct_itemrep, linetype=ct_itemrep), size = 2, show.legend=FALSE) + #labs(x = "Item Comparison", y = "Normalised Surprise", colour = "Item Representation", size = 5) + 
  theme(axis.text.x  = element_text(colour="grey20", size=64, angle=00, hjust=0.5, vjust=-1.0, face="plain"),
        axis.text.y  = element_text(colour="grey20", size=64, angle=00, hjust=0.0, vjust=0.0, face="plain"),  
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.border = element_rect(linetype = "solid", size=3, fill = NA),
        panel.grid.major = element_line(linetype = "dotdash", colour = "gray60", size=1.5),
        panel.grid.minor = element_line(linetype = "blank",   colour = "white",  size=1.5))

filename <- paste("interaction-4by2-l1-", PARAM_DATAGROUP, ".png", sep="")
imageFile <- paste(imageDirectory,filename,sep="/")
ggsave(file = imageFile)
readline(prompt="Press [enter] to continue")

# Contrast: Content vs Rating (within Full)
rcontrast(7.78, 76)
surprise$ct_previous <- surprise$ct_itemrep
surprise$ct_itemrep <- ifelse(surprise$itemrep %in% c("Model C", "Model D"), "Content", "Rating")
surpriseInt <- ggplot(surprise[surprise$ct_previous == "Full",], aes(itemcmp, metric, colour = ct_itemrep))
#surpriseInt + stat_summary(fun.y = mean, geom = "point") + stat_summary(fun.y = mean, geom = "line", aes(group= ct_itemrep)) + stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.2) + labs(x = "Item Comparison", y = "Mean Surprise", colour = "Item Representation") + ggtitle("Contrast: Content vs Rating (within Full)")  
surpriseInt + 
  stat_summary(fun.y = mean, geom = "point", size = 5, show.legend=FALSE) + 
  stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.05, size = 2, show.legend=FALSE) + 
  stat_summary(fun.y = mean, geom = "line", aes(group=ct_itemrep, linetype=ct_itemrep), size = 2, show.legend=FALSE) + #labs(x = "Item Comparison", y = "Normalised Surprise", colour = "Item Representation", size = 5) + 
  theme(axis.text.x  = element_text(colour="grey20", size=64, angle=00, hjust=0.5, vjust=-1.0, face="plain"),
        axis.text.y  = element_text(colour="grey20", size=64, angle=00, hjust=0.0, vjust=0.0, face="plain"),  
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.border = element_rect(linetype = "solid", size=3, fill = NA),
        panel.grid.major = element_line(linetype = "dotdash", colour = "gray60", size=1.5),
        panel.grid.minor = element_line(linetype = "blank",   colour = "white",  size=1.5))

filename <- paste("interaction-4by2-l2-", PARAM_DATAGROUP, ".png", sep="")
imageFile <- paste(imageDirectory,filename,sep="/")
ggsave(file = imageFile)
readline(prompt="Press [enter] to continue")

# Contrast: Content vs Rating (within Factorised)
rcontrast(-8.12, 76)
#surprise$ct_previous <- surprise$ct_itemrep
#surprise$ct_itemrep <- ifelse(surprise$itemrep %in% c("Model C", "Model D"), "Content", "Rating")
surpriseInt <- ggplot(surprise[surprise$ct_previous == "Factorised",], aes(itemcmp, metric, colour = ct_itemrep))
#surpriseInt + stat_summary(fun.y = mean, geom = "point") + stat_summary(fun.y = mean, geom = "line", aes(group= ct_itemrep)) + stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.2) + labs(x = "Item Comparison", y = "Mean Surprise", colour = "Item Representation") + ggtitle("Contrast: Content vs Rating (within Factorised)")
surpriseInt + 
  stat_summary(fun.y = mean, geom = "point", size = 5, show.legend=FALSE) + 
  stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.05, size = 2, show.legend=FALSE) + 
  stat_summary(fun.y = mean, geom = "line", aes(group=ct_itemrep, linetype=ct_itemrep), size = 2, show.legend=FALSE) + #labs(x = "Item Comparison", y = "Normalised Surprise", colour = "Item Representation", size = 5) + 
  theme(axis.text.x  = element_text(colour="grey20", size=64, angle=00, hjust=0.5, vjust=-1.0, face="plain"),
        axis.text.y  = element_text(colour="grey20", size=64, angle=00, hjust=0.0, vjust=0.0, face="plain"),  
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.border = element_rect(linetype = "solid", size=3, fill = NA),
        panel.grid.major = element_line(linetype = "dotdash", colour = "gray60", size=1.5),
        panel.grid.minor = element_line(linetype = "blank",   colour = "white",  size=1.5))

filename <- paste("interaction-4by2-l3-", PARAM_DATAGROUP, ".png", sep="")
imageFile <- paste(imageDirectory,filename,sep="/")
ggsave(file = imageFile)
